import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Grid,
  Box,
  Typography,
  Avatar,
  Button,
  Tabs,
  Tab,
  Divider,
  CircularProgress,
  Paper
} from '@mui/material';
import { PersonAdd, Check } from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import PostCard from '../components/PostCard';
import { toast } from 'react-toastify';

const Profile = () => {
  const { id } = useParams();
  const { user: currentUser } = useAuth();
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [following, setFollowing] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [followLoading, setFollowLoading] = useState(false);

  useEffect(() => {
    const fetchUserAndPosts = async () => {
      try {
        setLoading(true);
        
        // Check if id exists before making API calls
        if (!id) {
          toast.error('Invalid user ID');
          setLoading(false);
          return;
        }
        
        // Fetch user data
        const userResponse = await api.get(`/users/${id}`);
        setUser(userResponse.data);
        
        // Check if current user is following this user
        if (currentUser && currentUser.following) {
          setFollowing(currentUser.following.some(followingId => followingId === id));
        }
        
        // Fetch user's posts
        const postsResponse = await api.get(`/posts?user=${id}`);
        setPosts(postsResponse.data);
      } catch (error) {
        console.error('Error fetching profile data:', error);
        toast.error('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };

    fetchUserAndPosts();
  }, [id, currentUser]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleFollow = async () => {
    try {
      if (!id) {
        toast.error('Invalid user ID');
        return;
      }
      
      setFollowLoading(true);
      await api.put(`/users/${id}/follow`);
      setFollowing(!following);
      toast.success(following ? 'Unfollowed user' : 'Following user');
    } catch (error) {
      console.error('Error following/unfollowing user:', error);
      toast.error('Failed to follow/unfollow user');
    } finally {
      setFollowLoading(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', pt: 10 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!user) {
    return (
      <Container sx={{ pt: 8 }}>
        <Typography variant="h5" color="error" align="center">
          User not found
        </Typography>
      </Container>
    );
  }

  // Safe comparison that handles undefined/null values
  const isOwnProfile = currentUser && user && 
                      currentUser._id && user._id &&
                      currentUser._id === user._id;

  return (
    <Container maxWidth="md" sx={{ pt: 8, pb: 4 }}>
      <Paper elevation={2} sx={{ p: 4, mb: 4, borderRadius: 2 }}>
        <Box className="profile-header">
          <Avatar
            src={user.profilePicture}
            alt={user.username}
            className="profile-avatar"
            sx={{ width: 150, height: 150 }}
          />
          
          <Box sx={{ flex: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h4">{user.username}</Typography>
              
              {!isOwnProfile && (
                <Button
                  variant={following ? "outlined" : "contained"}
                  color="primary"
                  startIcon={following ? <Check /> : <PersonAdd />}
                  onClick={handleFollow}
                  disabled={followLoading}
                >
                  {following ? 'Following' : 'Follow'}
                </Button>
              )}
            </Box>
            
            <Box sx={{ display: 'flex', gap: 3, mb: 2 }}>
              <Typography variant="body1">
                <strong>{posts.length}</strong> Posts
              </Typography>
              <Typography variant="body1">
                <strong>{user.followers?.length || 0}</strong> Followers
              </Typography>
              <Typography variant="body1">
                <strong>{user.following?.length || 0}</strong> Following
              </Typography>
            </Box>
            
            <Typography variant="body1" sx={{ mb: 1 }}>
              {user.bio || 'No bio yet'}
            </Typography>
          </Box>
        </Box>
      </Paper>
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange} centered>
          <Tab label="Posts" />
          <Tab label="About" />
        </Tabs>
      </Box>
      
      {tabValue === 0 ? (
        posts.length > 0 ? (
          <Grid container spacing={3}>
            {posts.map(post => (
              <Grid item xs={12} key={post._id}>
                <PostCard post={post} />
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography variant="body1" align="center" sx={{ py: 4 }}>
            No posts yet
          </Typography>
        )
      ) : (
        <Box sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>User Information</Typography>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="body1" gutterBottom>
            <strong>Username:</strong> {user.username}
          </Typography>
          <Typography variant="body1" gutterBottom>
            <strong>Email:</strong> {user.email}
          </Typography>
          <Typography variant="body1" gutterBottom>
            <strong>Joined:</strong> {new Date(user.createdAt).toLocaleDateString()}
          </Typography>
          <Typography variant="body1" gutterBottom>
            <strong>Bio:</strong> {user.bio || 'No bio provided'}
          </Typography>
        </Box>
      )}
    </Container>
  );
};

export default Profile; 