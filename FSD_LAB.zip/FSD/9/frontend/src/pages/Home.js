import React, { useState, useEffect } from 'react';
import { Container, Grid, Typography, Box, CircularProgress } from '@mui/material';
import api from '../services/api';
import PostCard from '../components/PostCard';
import CreatePostForm from '../components/CreatePostForm';

const Home = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoading(true);
        const response = await api.get('/posts');
        setPosts(response.data);
      } catch (err) {
        console.error('Error fetching posts:', err);
        setError('Failed to load posts. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  const handleNewPost = (newPost) => {
    setPosts([newPost, ...posts]);
  };

  return (
    <Container maxWidth="md" sx={{ pt: 8, pb: 4 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <CreatePostForm onPostCreated={handleNewPost} />
        </Grid>

        {loading ? (
          <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
            <CircularProgress />
          </Grid>
        ) : error ? (
          <Grid item xs={12}>
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="body1" color="error">
                {error}
              </Typography>
            </Box>
          </Grid>
        ) : posts.length === 0 ? (
          <Grid item xs={12}>
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="body1">
                No posts yet. Be the first to post something!
              </Typography>
            </Box>
          </Grid>
        ) : (
          posts.map((post) => (
            <Grid item xs={12} key={post._id}>
              <PostCard post={post} />
            </Grid>
          ))
        )}
      </Grid>
    </Container>
  );
};

export default Home; 