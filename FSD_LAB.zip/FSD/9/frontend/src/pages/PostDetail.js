import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Box,
  Typography,
  TextField,
  Button,
  Avatar,
  Card,
  CardHeader,
  CardContent,
  CardMedia,
  CardActions,
  IconButton,
  Divider,
  CircularProgress,
  Menu,
  MenuItem
} from '@mui/material';
import {
  MoreVert as MoreVertIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Favorite as FavoriteIcon,
  ArrowBack as ArrowBackIcon,
  Send as SendIcon
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { toast } from 'react-toastify';

const PostDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [comment, setComment] = useState('');
  const [commentLoading, setCommentLoading] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        setLoading(true);
        
        // Validate ID before making API call
        if (!id) {
          toast.error('Invalid post ID');
          navigate('/');
          return;
        }
        
        const response = await api.get(`/posts/${id}`);
        setPost(response.data);
        
        // Safely check if the post is liked by the current user
        if (user && response.data.likes && Array.isArray(response.data.likes)) {
          setLiked(response.data.likes.some(likeId => likeId === user._id));
        }
        
        setLikesCount(response.data.likes ? response.data.likes.length : 0);
      } catch (error) {
        console.error('Error fetching post:', error);
        toast.error('Failed to load post');
        navigate('/');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchPost();
    } else {
      navigate('/');
    }
  }, [id, user, navigate]);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLike = async () => {
    try {
      if (!id) {
        toast.error('Invalid post ID');
        return;
      }
      
      await api.put(`/posts/${id}/like`);
      setLiked(!liked);
      setLikesCount(liked ? likesCount - 1 : likesCount + 1);
    } catch (error) {
      toast.error('Failed to like post');
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim() || !id) return;

    try {
      setCommentLoading(true);
      const response = await api.post(`/posts/${id}/comments`, { text: comment });
      
      // Update post with new comments
      setPost({
        ...post,
        comments: response.data
      });
      
      setComment('');
      toast.success('Comment added');
    } catch (error) {
      toast.error('Failed to add comment');
    } finally {
      setCommentLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      if (!id) {
        toast.error('Invalid post ID');
        return;
      }
      
      await api.delete(`/posts/${id}`);
      toast.success('Post deleted successfully');
      navigate('/');
    } catch (error) {
      toast.error('Failed to delete post');
    }
    handleMenuClose();
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', pt: 10 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!post) {
    return (
      <Container sx={{ pt: 8 }}>
        <Typography variant="h5" color="error" align="center">
          Post not found
        </Typography>
      </Container>
    );
  }

  // Safely check if the current user is the post owner
  const isPostOwner = user && post.user && 
                     user._id && post.user._id && 
                     user._id === post.user._id;

  return (
    <Container maxWidth="md" sx={{ pt: 8, pb: 4 }}>
      <Box sx={{ mb: 2 }}>
        <Button 
          startIcon={<ArrowBackIcon />} 
          onClick={() => navigate(-1)}
          sx={{ mb: 2 }}
        >
          Back
        </Button>
        
        <Card>
          <CardHeader
            avatar={
              <Avatar
                src={post.user.profilePicture}
                alt={post.user.username}
                onClick={() => navigate(`/profile/${post.user._id}`)}
                sx={{ cursor: 'pointer' }}
              >
                {post.user.username?.charAt(0).toUpperCase()}
              </Avatar>
            }
            action={
              isPostOwner && (
                <IconButton aria-label="settings" onClick={handleMenuOpen}>
                  <MoreVertIcon />
                </IconButton>
              )
            }
            title={
              <Typography
                variant="subtitle1"
                component="span"
                sx={{ fontWeight: 'bold', cursor: 'pointer' }}
                onClick={() => navigate(`/profile/${post.user._id}`)}
              >
                {post.user.username}
              </Typography>
            }
            subheader={new Date(post.createdAt).toLocaleString()}
          />

          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            <MenuItem onClick={handleDelete}>Delete</MenuItem>
          </Menu>

          {post.image && (
            <CardMedia
              component="img"
              image={post.image}
              alt="Post image"
              sx={{ maxHeight: 500, objectFit: 'contain' }}
            />
          )}

          <CardContent>
            <Typography variant="body1">{post.content}</Typography>
          </CardContent>

          <CardActions>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <IconButton onClick={handleLike} color={liked ? 'primary' : 'default'}>
                {liked ? <FavoriteIcon /> : <FavoriteBorderIcon />}
              </IconButton>
              <Typography variant="body2">{likesCount} likes</Typography>
            </Box>
          </CardActions>

          <Divider />

          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Comments ({post.comments ? post.comments.length : 0})
            </Typography>
            
            <Box component="form" onSubmit={handleCommentSubmit} sx={{ display: 'flex', mb: 3 }}>
              <TextField
                fullWidth
                size="small"
                placeholder="Add a comment..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                sx={{ mr: 1 }}
              />
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={!comment.trim() || commentLoading}
                startIcon={<SendIcon />}
              >
                Post
              </Button>
            </Box>
            
            {post.comments && post.comments.length > 0 ? (
              post.comments.map((comment, index) => (
                <Box key={comment._id || index} sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', mb: 1 }}>
                    <Avatar
                      src={comment.user && comment.user.profilePicture}
                      alt={comment.user && comment.user.username}
                      sx={{ width: 32, height: 32, mr: 1.5 }}
                      onClick={() => comment.user && comment.user._id && navigate(`/profile/${comment.user._id}`)}
                    >
                      {comment.user && comment.user.username ? comment.user.username.charAt(0).toUpperCase() : '?'}
                    </Avatar>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Typography 
                          variant="subtitle2" 
                          component="span" 
                          sx={{ fontWeight: 'bold', mr: 1, cursor: 'pointer' }}
                          onClick={() => comment.user && comment.user._id && navigate(`/profile/${comment.user._id}`)}
                        >
                          {comment.user ? comment.user.username : 'Unknown user'}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {comment.date ? new Date(comment.date).toLocaleString() : 'Unknown date'}
                        </Typography>
                      </Box>
                      <Typography variant="body2">{comment.text}</Typography>
                    </Box>
                  </Box>
                </Box>
              ))
            ) : (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>
                No comments yet
              </Typography>
            )}
          </Box>
        </Card>
      </Box>
    </Container>
  );
};

export default PostDetail; 