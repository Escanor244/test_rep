import React, { useState } from 'react';
import {
  Card,
  CardContent,
  TextField,
  Button,
  Box,
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress
} from '@mui/material';
import {
  Image as ImageIcon,
  Public as PublicIcon,
  People as PeopleIcon,
  Lock as LockIcon
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../services/api';

const CreatePostForm = ({ onPostCreated }) => {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [image, setImage] = useState(null);
  const [privacy, setPrivacy] = useState('public');
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImage(null);
    setImagePreview(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!content.trim() && !image) {
      toast.error('Please add some content or an image');
      return;
    }
    
    try {
      setLoading(true);
      
      // Create form data
      const formData = new FormData();
      formData.append('content', content);
      formData.append('privacy', privacy);
      if (image) {
        formData.append('image', image);
      }
      
      // Send request
      const response = await api.uploadFile('/posts', formData);
      
      // Success
      toast.success('Post created successfully');
      setContent('');
      setImage(null);
      setImagePreview(null);
      setPrivacy('public');
      
      // Notify parent
      if (onPostCreated) {
        onPostCreated(response.data);
      }
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardContent>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            multiline
            rows={3}
            placeholder={`What's on your mind, ${user?.username}?`}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            sx={{ mb: 2 }}
          />
          
          {imagePreview && (
            <Box sx={{ position: 'relative', mb: 2 }}>
              <img 
                src={imagePreview} 
                alt="Preview" 
                style={{ 
                  width: '100%', 
                  maxHeight: '200px', 
                  objectFit: 'contain',
                  borderRadius: '4px' 
                }} 
              />
              <IconButton 
                sx={{ 
                  position: 'absolute', 
                  top: 0, 
                  right: 0,
                  backgroundColor: 'rgba(0, 0, 0, 0.5)',
                  color: 'white',
                  '&:hover': {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)'
                  }
                }}
                onClick={handleRemoveImage}
              >
                &times;
              </IconButton>
            </Box>
          )}
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box>
              <input
                accept="image/*"
                id="post-image-input"
                type="file"
                onChange={handleImageChange}
                style={{ display: 'none' }}
              />
              <label htmlFor="post-image-input">
                <IconButton component="span" color="primary">
                  <ImageIcon />
                </IconButton>
              </label>
              
              <FormControl size="small" sx={{ minWidth: 120, ml: 1 }}>
                <InputLabel id="privacy-label">Privacy</InputLabel>
                <Select
                  labelId="privacy-label"
                  value={privacy}
                  label="Privacy"
                  onChange={(e) => setPrivacy(e.target.value)}
                >
                  <MenuItem value="public">
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <PublicIcon fontSize="small" sx={{ mr: 1 }} />
                      Public
                    </Box>
                  </MenuItem>
                  <MenuItem value="followers">
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <PeopleIcon fontSize="small" sx={{ mr: 1 }} />
                      Followers
                    </Box>
                  </MenuItem>
                  <MenuItem value="private">
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <LockIcon fontSize="small" sx={{ mr: 1 }} />
                      Private
                    </Box>
                  </MenuItem>
                </Select>
              </FormControl>
            </Box>
            
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={(!content.trim() && !image) || loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Post'}
            </Button>
          </Box>
        </form>
      </CardContent>
    </Card>
  );
};

export default CreatePostForm; 