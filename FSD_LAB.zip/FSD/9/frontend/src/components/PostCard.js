import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Card,
  CardHeader,
  CardContent,
  CardActions,
  Avatar,
  IconButton,
  Typography,
  Box,
  Menu,
  MenuItem,
  CardMedia,
  TextField,
  Button,
  Divider
} from '@mui/material';
import {
  MoreVert as MoreVertIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Favorite as FavoriteIcon,
  ChatBubbleOutline as CommentIcon,
  Send as SendIcon
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../services/api';

const PostCard = ({ post }) => {
  const { user } = useAuth();
  const [anchorEl, setAnchorEl] = useState(null);
  const [liked, setLiked] = useState(post.likes.includes(user?.id));
  const [likesCount, setLikesCount] = useState(post.likes.length);
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState(post.comments || []);
  const [submitting, setSubmitting] = useState(false);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLike = async () => {
    try {
      await api.put(`/posts/${post._id}/like`);
      setLiked(!liked);
      setLikesCount(liked ? likesCount - 1 : likesCount + 1);
    } catch (error) {
      toast.error('Failed to like post');
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    try {
      setSubmitting(true);
      const response = await api.post(`/posts/${post._id}/comments`, { text: comment });
      setComments(response.data);
      setComment('');
      if (!showComments) setShowComments(true);
    } catch (error) {
      toast.error('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card sx={{ mb: 3 }}>
      <CardHeader
        avatar={
          <Avatar
            component={Link}
            to={`/profile/${post.user._id}`}
            src={post.user.profilePicture}
            alt={post.user.username}
          >
            {post.user.username?.charAt(0).toUpperCase()}
          </Avatar>
        }
        action={
          post.user._id === user?.id && (
            <IconButton aria-label="settings" onClick={handleMenuOpen}>
              <MoreVertIcon />
            </IconButton>
          )
        }
        title={
          <Typography
            variant="subtitle1"
            component={Link}
            to={`/profile/${post.user._id}`}
            sx={{ fontWeight: 'bold', textDecoration: 'none', color: 'inherit' }}
          >
            {post.user.username}
          </Typography>
        }
        subheader={new Date(post.createdAt).toLocaleString()}
      />

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleMenuClose}>Edit</MenuItem>
        <MenuItem onClick={handleMenuClose}>Delete</MenuItem>
      </Menu>

      {post.image && (
        <CardMedia
          component="img"
          image={post.image}
          alt="Post image"
          sx={{ maxHeight: 500 }}
        />
      )}

      <CardContent>
        <Typography variant="body1">{post.content}</Typography>
      </CardContent>

      <CardActions disableSpacing>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <IconButton onClick={handleLike} color={liked ? 'primary' : 'default'}>
            {liked ? <FavoriteIcon /> : <FavoriteBorderIcon />}
          </IconButton>
          <Typography variant="body2">{likesCount}</Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
          <IconButton onClick={() => setShowComments(!showComments)}>
            <CommentIcon />
          </IconButton>
          <Typography variant="body2">{comments.length}</Typography>
        </Box>
      </CardActions>

      {showComments && (
        <Box sx={{ p: 2 }}>
          <Divider sx={{ mb: 2 }} />
          
          <form onSubmit={handleCommentSubmit} style={{ display: 'flex', marginBottom: 16 }}>
            <TextField
              fullWidth
              size="small"
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              sx={{ mr: 1 }}
            />
            <Button
              variant="contained"
              color="primary"
              type="submit"
              disabled={!comment.trim() || submitting}
              startIcon={<SendIcon />}
            >
              Post
            </Button>
          </form>

          {comments.length > 0 ? (
            comments.map((comment, index) => (
              <Box key={comment._id || index} sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', mb: 1 }}>
                  <Avatar
                    src={comment.user.profilePicture}
                    alt={comment.user.username}
                    sx={{ width: 32, height: 32, mr: 1.5 }}
                  >
                    {comment.user.username?.charAt(0).toUpperCase()}
                  </Avatar>
                  <Box>
                    <Typography variant="subtitle2" component="span" sx={{ fontWeight: 'bold', mr: 1 }}>
                      {comment.user.username}
                    </Typography>
                    <Typography variant="body2">{comment.text}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {new Date(comment.date).toLocaleString()}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            ))
          ) : (
            <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>
              No comments yet
            </Typography>
          )}
        </Box>
      )}
    </Card>
  );
};

export default PostCard; 