import axios from 'axios';

const baseURL = process.env.REACT_APP_API_URL || '/api';

const instance = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
instance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
instance.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized error
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
    }
    return Promise.reject(error);
  }
);

const api = {
  setToken: (token) => {
    instance.defaults.headers.common.Authorization = `Bearer ${token}`;
  },
  
  removeToken: () => {
    delete instance.defaults.headers.common.Authorization;
  },
  
  // Auth endpoints
  post: (url, data) => instance.post(url, data),
  get: (url, config) => instance.get(url, config),
  put: (url, data) => instance.put(url, data),
  delete: (url) => instance.delete(url),
  
  // Upload with form data
  uploadFile: (url, formData) => {
    return instance.post(url, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  }
};

export default api; 