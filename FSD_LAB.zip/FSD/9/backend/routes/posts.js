const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const postController = require('../controllers/postController');
const { authenticate } = require('../middleware/auth');
const multer = require('multer');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    // Accept images only
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
      return cb(new Error('Only image files are allowed!'), false);
    }
    cb(null, true);
  }
});

// All routes below this require authentication
router.use(authenticate);

// @route   POST /api/posts
// @desc    Create a post
// @access  Private
router.post('/', [
  upload.single('image'),
  check('content', 'Content is required').not().isEmpty()
], postController.createPost);

// @route   GET /api/posts
// @desc    Get all posts for feed
// @access  Private
router.get('/', postController.getPosts);

// @route   GET /api/posts/:id
// @desc    Get post by ID
// @access  Private
router.get('/:id', postController.getPost);

// @route   PUT /api/posts/:id
// @desc    Update a post
// @access  Private
router.put('/:id', upload.single('image'), postController.updatePost);

// @route   DELETE /api/posts/:id
// @desc    Delete a post
// @access  Private
router.delete('/:id', postController.deletePost);

// @route   PUT /api/posts/:id/like
// @desc    Like or unlike a post
// @access  Private
router.put('/:id/like', postController.toggleLike);

// @route   POST /api/posts/:id/comments
// @desc    Comment on a post
// @access  Private
router.post('/:id/comments', [
  check('text', 'Text is required').not().isEmpty()
], postController.addComment);

// @route   DELETE /api/posts/:postId/comments/:commentId
// @desc    Delete comment
// @access  Private
router.delete('/:postId/comments/:commentId', postController.deleteComment);

module.exports = router; 