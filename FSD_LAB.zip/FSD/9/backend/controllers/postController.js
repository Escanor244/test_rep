const Post = require('../models/Post');
const User = require('../models/User');
const { validationResult } = require('express-validator');

// Create a new post
exports.createPost = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { content, privacy } = req.body;
    const image = req.file ? req.file.path : null;

    const newPost = new Post({
      user: req.user.id,
      content,
      image,
      privacy: privacy || 'public'
    });

    const post = await newPost.save();

    // Populate user data
    const populatedPost = await Post.findById(post._id).populate('user', 'username profilePicture');

    res.status(201).json(populatedPost);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all posts (feed)
exports.getPosts = async (req, res) => {
  try {
    const currentUser = req.user;
    
    // Get users that the current user is following
    const following = [...currentUser.following, currentUser._id];
    
    // Get public posts and posts from users the current user follows
    const posts = await Post.find({
      $or: [
        { privacy: 'public' },
        { user: { $in: following }, privacy: 'followers' },
        { user: currentUser._id }
      ]
    })
      .sort({ createdAt: -1 })
      .populate('user', 'username profilePicture')
      .populate('comments.user', 'username profilePicture');
    
    res.json(posts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get a single post
exports.getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('user', 'username profilePicture')
      .populate('comments.user', 'username profilePicture');
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check if user has permission to view post
    const currentUser = req.user;
    if (post.privacy === 'private' && post.user._id.toString() !== currentUser._id.toString()) {
      return res.status(403).json({ message: 'You do not have permission to view this post' });
    }
    
    if (post.privacy === 'followers' && 
        post.user._id.toString() !== currentUser._id.toString() && 
        !currentUser.following.includes(post.user._id)) {
      return res.status(403).json({ message: 'You must follow the user to see this post' });
    }
    
    res.json(post);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update a post
exports.updatePost = async (req, res) => {
  try {
    const { content, privacy } = req.body;
    
    // Find post
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check post ownership
    if (post.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'User not authorized' });
    }
    
    // Update fields
    if (content) post.content = content;
    if (privacy) post.privacy = privacy;
    if (req.file) post.image = req.file.path;
    
    await post.save();
    
    res.json(post);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete a post
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check post ownership
    if (post.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'User not authorized' });
    }
    
    await post.remove();
    
    res.json({ message: 'Post removed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Like/unlike a post
exports.toggleLike = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check if post already liked
    const alreadyLiked = post.likes.some(
      like => like.toString() === req.user.id
    );
    
    if (alreadyLiked) {
      // Unlike
      post.likes = post.likes.filter(
        like => like.toString() !== req.user.id
      );
    } else {
      // Like
      post.likes.push(req.user.id);
    }
    
    await post.save();
    
    res.json(post.likes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Comment on a post
exports.addComment = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    const newComment = {
      user: req.user.id,
      text: req.body.text
    };
    
    post.comments.unshift(newComment);
    
    await post.save();
    
    // Return the post with populated comments
    const updatedPost = await Post.findById(req.params.id)
      .populate('comments.user', 'username profilePicture');
    
    res.json(updatedPost.comments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete a comment
exports.deleteComment = async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Find comment
    const comment = post.comments.find(
      comment => comment.id === req.params.commentId
    );
    
    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }
    
    // Check comment ownership
    if (comment.user.toString() !== req.user.id && post.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'User not authorized' });
    }
    
    // Remove comment
    post.comments = post.comments.filter(
      comment => comment.id !== req.params.commentId
    );
    
    await post.save();
    
    res.json(post.comments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
}; 